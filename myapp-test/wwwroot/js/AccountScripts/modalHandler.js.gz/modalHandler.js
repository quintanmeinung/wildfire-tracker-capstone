document.addEventListener("DOMContentLoaded", function () {
    // Get the profile link
    var profileLink = document.getElementById("manage");

    // Get the profile modal
    var profileModal = new bootstrap.Modal(document.getElementById('profileModal'));

    // Add click event listener to the profile link
    if (profileLink) {
        profileLink.addEventListener("click", function (e) {
            e.preventDefault(); // Prevent default link behavior
            profileModal.show(); // Show the modal
        });
    }
});